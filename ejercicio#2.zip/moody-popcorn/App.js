import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Constants from 'expo-constants';

// You can import from local files
import FilmsScreen from './components/screens/FilmsScreen';
import SeriesScreen from './components/screens/SeriesScreen';
import SoonScreen from './components/screens/SoonScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
      
        <Tab.Screen
          name="Películas"
          component={FilmsScreen}
          options={{
            tabBarLabel: 'Películas',
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="video-vintage" color={color} size={size} />
            ),
          }}
        />

        <Tab.Screen
          name="Series"
          component={SeriesScreen}
          options={{
            tabBarLabel: 'Series',
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="form-select" color={color} size={size} />
            ),
          }}
        />

        <Tab.Screen
          name="Próximamente"
          component={SoonScreen}
          options={{
            tabBarLabel: 'Próximamente',
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="progress-clock" color={color} size={size} />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}