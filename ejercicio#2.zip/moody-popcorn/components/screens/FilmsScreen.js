import * as React from 'react';
import { Text, View, StyleSheet, Image, ScrollView } from 'react-native';

export default function FilmsScreen() {
  return (
    <ScrollView style={styles.container}>
      <View>
        <Image style={styles.mainImage} source={require('../../assets/img/movies.jpg')}/>
      </View>

      <View style={styles.contentContainer}>
        <View>
          <Text style={styles.title}>Comedia</Text>
          <View style={styles.categoryContainer}>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/hangover1.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/hangover2.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/hangover3.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/sonic.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/supercool.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/comedy/wolf.jpg')}/>
          </View>
        </View>

        <View>
          <Text style={styles.title}>Romance</Text>
          <View style={styles.categoryContainer}>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/deriva.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/ciudad.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/marry.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/pasajeros.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/teoria.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/romance/ventana.jpg')}/>
          </View>
        </View>

        <View>
          <Text style={styles.title}>Acción</Text>
          <View style={styles.categoryContainer}>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/athena.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/bullet.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/lou.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/memoria.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/moonfall.jpg')}/>
            <Image style={styles.categoryImage} source={require('../../assets/img/action/topgun.jpg')}/>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    flexDirection: 'column',
    backgroundColor: 'white'
  },
  contentContainer: {
    padding: 8
  },
  mainImage: {
    width: '100%',
    height: 70
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    backgroundColor: '#ecf4f2',
    alignContent: 'center',
    justifyContent: 'center'
  },
  categoryImage: {
    width: '25%',
    height: 200,
    margin: 10,
    resizeMode: 'contain'
  },
  title: {
    fontSize: 25,
    marginTop: 25,
    padding: 10,
    textAlign: 'center',
    backgroundColor: '#a1a5a4',
    width: '100%'
  }
}) 