import * as React from 'react';
import { Text, View, StyleSheet, ScrollView, Image } from 'react-native';

export default function SeriesScreen() {
  return (
    <ScrollView style={styles.container}>
      <View>
        <Image />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    flexDirection: 'column',
    backgroundColor: 'white'
  }
});