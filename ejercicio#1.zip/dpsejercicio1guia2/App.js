import { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import { CoffeeOutlined } from '@ant-design/icons';
import { Input } from 'antd';

const sizeData = [
  { label: 'Short 8 onz', value: 1, price: 1.0 },
  { label: 'Tall 12 onz', value: 2, price: 1.5 },
  { label: 'Grande 16 onz', value: 3, price: 2.0 },
];

const coffeData = [
  { label: 'Mocha', value: 1, price: 2.0 },
  { label: 'Te chai', value: 2, price: 2.5 },
  { label: 'Americano', value: 3, price: 1.5 },
  { label: 'Frapper', value: 4, price: 3.0 },
];

const paymentData = [
  { label: 'Efectivo', value: 1 },
  { label: 'Tarjeta', value: 2 },
];

export default function App() {
  const [isFirstFocus, setIsFirstFocus] = useState(false);
  const [isSecondFocus, setIsSecondFocus] = useState(false);
  const [isThirdFocus, setIsThirdFocus] = useState(false);

  const [sizevalue, setSizeValue] = useState(null);
  const [coffevalue, setCoffeValue] = useState(null);
  const [paymentvalue, setPaymentValue] = useState(null);
  const [quantityvalue, setQuantityValue] = useState(null);

  const [quantityView, setQuantityView] = useState('xxx');
  const [sizeView, setSizeView] = useState('xxx');
  const [typeView, setTypeView] = useState('xxx');
  const [paymentView, setPaymentView] = useState('xxx');
  const [discountView, setDiscountView] = useState('xxx');
  const [totalView, setTotalView] = useState('xxx');

  const plusQua = () => {
    setQuantityValue(quantityvalue + 1);
  };
  const minusQua = () => {
    if (quantityvalue > 0) {
      setQuantityValue(quantityvalue - 1);
    }
  };
  const onTextChange = (value) => {
    if (value < 0) {
      setQuantityValue(0);
    } else {
      setQuantityValue(value);
    }
  };

  const calculate = () => {
    let total = 0;
    let discount = 0;
    let subtotal = 0;
    if (
      quantityvalue != null &&
      sizevalue != null &&
      coffevalue != null &&
      paymentvalue != null
    ) {
      subtotal = (coffevalue.price + sizevalue.price) * quantityvalue;
      if (paymentvalue.value == 1) {
        discount = 0.15;
      } else if (paymentvalue.value == 2) {
        discount = 0.05;
      }
      total = (1 - discount) * subtotal;
      setDiscountView(discount * 100 + '%');
      setTotalView('$ ' + total.toFixed(2));
      setQuantityView(quantityvalue);
      setSizeView(sizevalue.label);
      setTypeView(coffevalue.label);
      setPaymentView(paymentvalue.label);
    }
  };

  const titleOne = <Text style={styles.inputText}>+</Text>;
  const titleTwo = <Text style={styles.inputText}> - </Text>;

  return (
    <View>
      <View style={styles.innerContainer}>
        <Text style={styles.headerText}>StarBosco APP</Text>
        <View style={styles.row}>
          <Dropdown
            style={[styles.dropdown, isFirstFocus && { borderColor: 'blue' }]}
            data={sizeData}
            maxHeight={300}
            labelField="label"
            valueField="value"
            placeholder={!isFirstFocus ? 'Selecione tamaño de café' : '...'}
            value={sizevalue}
            onFocus={() => setIsFirstFocus(true)}
            onBlur={() => setIsFirstFocus(false)}
            onChange={(item) => {
              setSizeValue(item);
              setIsFirstFocus(false);
            }}
            renderLeftIcon={() => <CoffeeOutlined />}
          />
        </View>
        <View style={styles.row}>
          <Dropdown
            style={[styles.dropdown, isSecondFocus && { borderColor: 'blue' }]}
            data={coffeData}
            maxHeight={300}
            labelField="label"
            valueField="value"
            placeholder={!isSecondFocus ? 'Selecione tipo de café' : '...'}
            value={coffevalue}
            onFocus={() => setIsSecondFocus(true)}
            onBlur={() => setIsSecondFocus(false)}
            onChange={(item) => {
              setCoffeValue(item);
              setIsSecondFocus(false);
            }}
            renderLeftIcon={() => <CoffeeOutlined />}
          />
        </View>
        <View style={styles.row}>
          <View style={styles.rowCol2}>
            <Dropdown
              style={[styles.dropdown, isThirdFocus && { borderColor: 'blue' }]}
              data={paymentData}
              maxHeight={300}
              labelField="label"
              valueField="value"
              placeholder={!isThirdFocus ? 'Tipo de Pago' : '...'}
              value={paymentvalue}
              onFocus={() => setIsThirdFocus(true)}
              onBlur={() => setIsThirdFocus(false)}
              onChange={(item) => {
                setPaymentValue(item);
                setIsThirdFocus(false);
              }}
              renderLeftIcon={() => <CoffeeOutlined />}
            />
          </View>
          <View style={styles.rowCol2}>
            <View style={styles.btnNumber}>
              <Button onPress={minusQua} title={titleTwo} color="white" />
            </View>
            <Input
              style={styles.numberInput}
              value={quantityvalue}
              placeholder="0"
            />
            <View style={styles.btnNumber}>
              <Button onPress={plusQua} title={titleOne} color="white" />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.resumeContainer}>
        <Text style={styles.headerText}>RESUMEN</Text>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Cantidad Solicitada:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{quantityView}</View>
        </View>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Tamaño:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{sizeView}</View>
        </View>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Tipo Cafe:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{typeView}</View>
        </View>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Tipo de Pago:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{paymentView}</View>
        </View>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Descuento %:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{discountView}</View>
        </View>
        <View style={styles.row2}>
          <View style={styles.rowCol2}>Total a Pagar:</View>
          <View style={(styles.rowCol2, styles.textLeft)}>{totalView}</View>
        </View>
        <View style={styles.btnView}>
          <View style={styles.btnView2}>
            <Button onPress={calculate} title="Calcular" color="grey" />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerText: {
    margin: 10,
    fontSize: 25,
  },
  innerContainer: {
    backgroundColor: '#ABB2B9',
    height: '250px',
    border: '4px solid black',
    borderRadius: '10px',
    textAlign: 'center',
  },
  resumeContainer: {
    height: '300px',
    textAlign: 'center',
  },
  row: {
    width: '100%',
    marginBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  row2: {
    width: '100%',
    paddingLeft: 10,
    paddingRight: 10,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  rowCol2: {
    width: '50%',
    marginBottom: 10,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'end',
  },
  numberInput: {
    width: '40%',
    textAlign: 'center',
  },
  dropdown: {
    height: 50,
    borderColor: 'gray',
    backgroundColor: '#fff',
    borderWidth: 0.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    width: '100%',
    margin: 'auto',
  },
  btnNumber: {
    border: '1px solid gray',
    backgroundColor: 'white',
  },
  inputText: {
    color: '#000',
    fontSize: 20,
  },
  btnView: {
    width: '100%',
    textAlign: 'center',
    alignItems: 'center',
  },
  btnView2: {
    width: '80%',
    backgroundColor: 'grey',
    border: '3px solid #000',
  },
  textLeft: {
    textAlign: 'left',
    marginLeft: 10,
  },
});
